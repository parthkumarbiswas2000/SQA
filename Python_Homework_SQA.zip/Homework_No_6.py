#6. Given a dictionary, create two separate tuples: one for keys and one for values.student = {"name": "Zara", "age": 25, "city": "Bangladesh"}

student = {"name": "Zara","age":"25", "city": "Bangladesh"}

for i in student.values():
    print("Values: ",i)

for j in student.keys():
    print("Keys: ",j)
