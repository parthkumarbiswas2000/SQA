#2.Print numbers from 1 to 15. Skip numbers that are multiples of 4 using continue.
print("**********")


for i in range(1,16):
    if i == 4:
        print(f"Skipping {i}")
        continue
    print(i)

print("*****OR*****")

list = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]

for a in list:
    if a == 4:
        print(f"Skipping {i}")
        continue
    print(a)
