#7. Add "Mango" to the end of the list and "Grape" at index 2.fruits = ["Apple", "Banana", "Cherry", "Date"]

fruits = ["Apple", "Banana", "Cherry", "Date"]

fruits.append("Mango")
print(fruits)

fruits.insert(2,"Grapes")
print(fruits)
