#5. Check whether a number is a palindrome using a while loop.
number = int(input("Enter the  number to whether palindrome or not: "))
temp = number
reverse = 0
while number > 0:
    reverse = reverse * 10 + number % 10
    number = number // 10
if temp == reverse:
    print(temp,"is palindrome number")
else:
    print(temp,"is not palindrome number")

