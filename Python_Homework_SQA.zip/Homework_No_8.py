#8. Remove duplicates from the list while keeping unique elements. numbers = [1, 2, 2, 3, 4, 4, 5]

numbers = [1,2,2,3,4,4,5]
numbers.remove(2)
numbers.remove(4)

print(numbers)

print("********OR*******")
unique_elements = list(set(numbers))
print(unique_elements)