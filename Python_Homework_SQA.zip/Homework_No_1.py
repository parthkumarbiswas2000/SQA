#1.Print numbers from 1 to 20. Stop the loop if the number is 12 using break.

for m in range(1,21):
    if m == 12:
        break
    print(m)

print("*******or*******")

l = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]

for m in l:
    if m == 12:
        break
    print(m)
