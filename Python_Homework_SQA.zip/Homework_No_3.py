#3.Given List: items = ["pen", "book", "bottle", "laptop", "mouse"] Here,if the item is "laptop",use pass.Print all items.

items = ["pen", "book", "bottle", "laptop", "mouse"]
for item in items:
    if item == "laptop":
        pass
    print(item)
