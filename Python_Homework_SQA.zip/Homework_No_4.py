#4.Write a Python program using a while loop to print numbers from 10 down to 1 in descending order.

i = 11

while i > 1:
    i = i - 1
    print(i)
